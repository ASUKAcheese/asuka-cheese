// 購入先はここでまとめて変更できます。HTMLのhrefはJavaScript無効時の予備です。
window.ASUKA_LINKS = {
  "shop": "https://minne.com/@asuka-cheese",
  "hajime": "https://minne.com/items/22414099",
  "shiokaze": "https://minne.com/items/22269723",
  "yukinone": "https://minne.com/items/22378184",
  "set-6": "https://minne.com/items/22365953",
  "set-4": "https://minne.com/items/23092925"
};
// 測定IDが決まるまでは空欄にします。
window.ASUKA_GA4_ID = "";
